//event pada saat diklik
$('.scroll').on('click',function(e){
	//ambil isi href
	var tujuan=$(this).attr('href')
	//tangkap elements ybs
	var elemenTujuan=$(tujuan);
	//pindahkan scrool
	$('html,body').animate({
		scrollTop:elemenTujuan.offset().top-50
	},1250,'easeInOutExpo');

	e.preventDefault();

});

// about
$(window).on('load',function(){
	$('.pKiri').addClass('.pMuncul');

})
$(window).scroll(function(){
	var wScrool=$(this).scrollTop();
	//jumbotron
	$('.jumbotron img').css({
		'transform':'translate(0px,'+wScrool/8+'%)'

	});
	$('.jumbotron h1').css({
		'transform':'translate(0px,'+wScrool/4+'%)'

	});
	$('.jumbotron p').css({
		'transform':'translate(0px,'+wScrool/3.2+'%)'

	});
	//portfolio
	if(wScrool>$('.portfolio').offset().top-200){
		$('.portfolio .thumbnail').addClass('muncul');


		

	}
})